-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 39.107.237.39
-- Port     : 
-- Database : meizi
-- 
-- Part : #1
-- Date : 2018-10-28 17:14:56
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `t_api_inter_route`
-- -----------------------------
DROP TABLE IF EXISTS `t_api_inter_route`;
CREATE TABLE `t_api_inter_route` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自动增长id',
  `group_id` int(10) unsigned NOT NULL COMMENT '组id',
  `route_name` varchar(50) NOT NULL COMMENT '路由名称',
  `route_action` varchar(50) NOT NULL COMMENT '路由路径',
  `route_method` varchar(10) NOT NULL COMMENT '请求方法',
  `return_param` text COMMENT '返回参数',
  `remark` text COMMENT '备注信息',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='接口路由表';

-- -----------------------------
-- Records of `t_api_inter_route`
-- -----------------------------
INSERT INTO `t_api_inter_route` VALUES ('1', '2', '1213', '3243', '4324354', '43543544', '5465', '43546', '54656', '');
INSERT INTO `t_api_inter_route` VALUES ('2', '2', '43534', '43545', '54656', '4354654', '354354', '455646', '5465767', '');
INSERT INTO `t_api_inter_route` VALUES ('3', '3', '43545', '54656', '65767', '576687', '67687', '76878', '7687', '');
INSERT INTO `t_api_inter_route` VALUES ('4', '3', '5465778', '9877868', '6879879', '8779887', '6879879', '8798908', '7687987', '');
INSERT INTO `t_api_inter_route` VALUES ('5', '2', '大家饿哦', '第三遍', 'post', '', 'frtgtrhytht', '1537885415', '1537885415', '');
INSERT INTO `t_api_inter_route` VALUES ('6', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537885994', '1537885994', '');
INSERT INTO `t_api_inter_route` VALUES ('7', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537886022', '1537886022', '');
INSERT INTO `t_api_inter_route` VALUES ('8', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537886380', '1537886380', '');
INSERT INTO `t_api_inter_route` VALUES ('16', '0', '', '', '', '', '', '1539010701', '1539010701', '');
INSERT INTO `t_api_inter_route` VALUES ('17', '0', '', '', '', '', '', '1539010703', '1539010703', '');
INSERT INTO `t_api_inter_route` VALUES ('18', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540455826', '1540455826', '1');
INSERT INTO `t_api_inter_route` VALUES ('19', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540455831', '1540455831', '1');
INSERT INTO `t_api_inter_route` VALUES ('20', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540456131', '1540456131', '1');
INSERT INTO `t_api_inter_route` VALUES ('21', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540456188', '1540456188', '1');
INSERT INTO `t_api_inter_route` VALUES ('22', '4', '接口测试', 'test.login', 'POST', 'rfgrd', 'rgfetg', '1540457047', '1540457047', '1');
INSERT INTO `t_api_inter_route` VALUES ('23', '4', '接口测试', 'test.login', 'POST', 'rfgrd', 'rgfetg', '1540457103', '1540457103', '1');
INSERT INTO `t_api_inter_route` VALUES ('24', '4', 'sdf', 'fcsdfc', 'GET', 'fdgvdfgbfh跟他返回法国', '是的规范化', '1540458096', '1540458096', '1');

-- -----------------------------
-- Table structure for `t_api_role`
-- -----------------------------
DROP TABLE IF EXISTS `t_api_role`;
CREATE TABLE `t_api_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自动增长id',
  `role_name` varchar(30) NOT NULL COMMENT '角色名称',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `t_api_role`
-- -----------------------------
INSERT INTO `t_api_role` VALUES ('1', '管理员', '456546567', '465465466');
INSERT INTO `t_api_role` VALUES ('2', '角色22', '1535442150', '1535442150');
INSERT INTO `t_api_role` VALUES ('3', '角色33', '1535442219', '1535442219');
INSERT INTO `t_api_role` VALUES ('4', '角色44', '1535442280', '1535442280');
INSERT INTO `t_api_role` VALUES ('5', '角色4455', '1535442408', '1535442408');
INSERT INTO `t_api_role` VALUES ('6', '前端接入组', '1540288608', '1540288642');
INSERT INTO `t_api_role` VALUES ('7', '后端接口组', '1540288624', '1540288624');

-- -----------------------------
-- Table structure for `t_api_user`
-- -----------------------------
DROP TABLE IF EXISTS `t_api_user`;
CREATE TABLE `t_api_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自动增长id',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `password` varchar(70) NOT NULL COMMENT '密码',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  `salt` varchar(6) DEFAULT NULL COMMENT '盐值',
  `avatar` varchar(250) DEFAULT '' COMMENT '头像',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COMMENT='接口管理表';

-- -----------------------------
-- Records of `t_api_user`
-- -----------------------------
INSERT INTO `t_api_user` VALUES ('1', 'huang', '929a26b24f8b1b7a8cb8b124658579a3', '1537455505', '1537455505', 'qwerty', '');
INSERT INTO `t_api_user` VALUES ('91', '测试阿拉拉了', '12eccbdd9b32918131341f38907cbbb5', '1535177351', '1535177500', '', '');
INSERT INTO `t_api_user` VALUES ('92', '蔡少芬的', '6abba5d8ab1f4f32243e174beb754661', '1535191347', '1535191347', '', '');
INSERT INTO `t_api_user` VALUES ('93', '京东将从', 'e391925fac8db7c2563aad0a8028bda9', '1535271894', '1535271894', '', '');
INSERT INTO `t_api_user` VALUES ('95', '', 'd41d8cd98f00b204e9800998ecf8427e', '1537455496', '1537455496', '', '');
INSERT INTO `t_api_user` VALUES ('97', '啊啊啊', '0fd7c4881ba64b74ed72433fb38cefd7', '1540019374', '1540019374', 'hulOEo', '');
INSERT INTO `t_api_user` VALUES ('100', 'test', '42001b4a190d8c4ae6e797ebde73eee7', '1540020259', '1540020259', 'zgTFHJ', '');
INSERT INTO `t_api_user` VALUES ('103', 'aaa', 'e5da7700e409dc407e1b66249049e57b', '1540373366', '1540373366', 'RHqJaF', '/public/uploads/20181024/d5018c5c0fd8e74509ff953c404f5474.png');
INSERT INTO `t_api_user` VALUES ('105', 'html', '1be28dc34587a8b1b276ccc0a7ad6648', '1540431350', '1540431350', 'KS4Jpi', '/public/uploads/20181025/c39310c136b441a2fff85994296cb47b.png');
INSERT INTO `t_api_user` VALUES ('106', 'root', 'a0c62fac1fc1c9f90747ae7947d8b8e1', '1540533676', '1540533676', 'KAs8og', '/public/uploads/20181026/05d8282aad5ed7407a95653f2a193b94.png');
INSERT INTO `t_api_user` VALUES ('107', 'root1', 'b76a903c0dc782a96c7e6b26aa1ecdb5', '1540533846', '1540533846', '4uUJFt', '/public/uploads/20181026/d18f9cb51c7b33b9be2fe539360d925f.png');
INSERT INTO `t_api_user` VALUES ('108', 'test323', 'afe45ed311c26e9540035e782b72d602', '1540544994', '1540544994', '2j4PFz', '/public/uploads/20181026/09494edf89dca268284f7110ac748a28.png');
INSERT INTO `t_api_user` VALUES ('109', 'route', 'c2368cc5b3e5a9dde879277ea0197c0f', '1540708626', '1540708626', 'fLA57X', '/public/uploads/20181028/c4760a4ac33b0311e76508be7739a304.jpg');
INSERT INTO `t_api_user` VALUES ('110', 'test123', '58723a92f43d911e5e87de506ca3b0bd', '1540711556', '1540711556', 'bR7WBK', '/public/uploads/20181028/919a15616c67c7b63ab111259003630a.jpg');
