-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 39.107.237.39
-- Port     : 
-- Database : meizi
-- 
-- Part : #1
-- Date : 2018-10-28 17:09:02
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `t_api_inter_param`
-- -----------------------------
DROP TABLE IF EXISTS `t_api_inter_param`;
CREATE TABLE `t_api_inter_param` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自动增长id',
  `route_id` int(10) unsigned NOT NULL COMMENT '路由id',
  `param_name` varchar(50) NOT NULL COMMENT '参数名称',
  `param_type` varchar(10) NOT NULL COMMENT '参数类型',
  `is_required` int(1) unsigned DEFAULT '1' COMMENT '是否必须（1为是，2为否）',
  `param_comment` text COMMENT '参数解释',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='接口参数表';

-- -----------------------------
-- Records of `t_api_inter_param`
-- -----------------------------
INSERT INTO `t_api_inter_param` VALUES ('18', '18', 'username', 'string', '1', '用户账号', '1540455827', '1540455827');
INSERT INTO `t_api_inter_param` VALUES ('19', '18', 'password', 'string', '1', '用户密码', '1540455827', '1540455827');
INSERT INTO `t_api_inter_param` VALUES ('20', '19', 'username', 'string', '1', '用户账号', '1540455832', '1540455832');
INSERT INTO `t_api_inter_param` VALUES ('21', '19', 'password', 'string', '1', '用户密码', '1540455832', '1540455832');
INSERT INTO `t_api_inter_param` VALUES ('22', '20', 'username', 'string', '1', '用户账号', '1540456132', '1540456132');
INSERT INTO `t_api_inter_param` VALUES ('23', '20', 'password', 'string', '1', '用户密码', '1540456132', '1540456132');
INSERT INTO `t_api_inter_param` VALUES ('24', '21', 'username', 'string', '1', '用户账号', '1540456188', '1540456188');
INSERT INTO `t_api_inter_param` VALUES ('25', '21', 'password', 'string', '1', '用户密码', '1540456188', '1540456188');
INSERT INTO `t_api_inter_param` VALUES ('26', '22', 'df', 'long', '1', 'freg', '1540457047', '1540457047');
INSERT INTO `t_api_inter_param` VALUES ('27', '22', 'rfge', 'long', '2', 'rgfeg', '1540457047', '1540457047');
INSERT INTO `t_api_inter_param` VALUES ('28', '23', 'df', 'long', '1', 'freg', '1540457103', '1540457103');
INSERT INTO `t_api_inter_param` VALUES ('29', '23', 'rfge', 'long', '2', 'rgfeg', '1540457103', '1540457103');
INSERT INTO `t_api_inter_param` VALUES ('30', '24', 'fsd', 'long', '2', 'fvdgvdgvf', '1540458096', '1540458096');

-- -----------------------------
-- Table structure for `t_api_inter_route`
-- -----------------------------
DROP TABLE IF EXISTS `t_api_inter_route`;
CREATE TABLE `t_api_inter_route` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自动增长id',
  `group_id` int(10) unsigned NOT NULL COMMENT '组id',
  `route_name` varchar(50) NOT NULL COMMENT '路由名称',
  `route_action` varchar(50) NOT NULL COMMENT '路由路径',
  `route_method` varchar(10) NOT NULL COMMENT '请求方法',
  `return_param` text COMMENT '返回参数',
  `remark` text COMMENT '备注信息',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='接口路由表';

-- -----------------------------
-- Records of `t_api_inter_route`
-- -----------------------------
INSERT INTO `t_api_inter_route` VALUES ('1', '2', '1213', '3243', '4324354', '43543544', '5465', '43546', '54656', '');
INSERT INTO `t_api_inter_route` VALUES ('2', '2', '43534', '43545', '54656', '4354654', '354354', '455646', '5465767', '');
INSERT INTO `t_api_inter_route` VALUES ('3', '3', '43545', '54656', '65767', '576687', '67687', '76878', '7687', '');
INSERT INTO `t_api_inter_route` VALUES ('4', '3', '5465778', '9877868', '6879879', '8779887', '6879879', '8798908', '7687987', '');
INSERT INTO `t_api_inter_route` VALUES ('5', '2', '大家饿哦', '第三遍', 'post', '', 'frtgtrhytht', '1537885415', '1537885415', '');
INSERT INTO `t_api_inter_route` VALUES ('6', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537885994', '1537885994', '');
INSERT INTO `t_api_inter_route` VALUES ('7', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537886022', '1537886022', '');
INSERT INTO `t_api_inter_route` VALUES ('8', '2', '大家饿哦', '第三遍', 'post', 'dewsffergtr', 'frtgtrhytht', '1537886380', '1537886380', '');
INSERT INTO `t_api_inter_route` VALUES ('16', '0', '', '', '', '', '', '1539010701', '1539010701', '');
INSERT INTO `t_api_inter_route` VALUES ('17', '0', '', '', '', '', '', '1539010703', '1539010703', '');
INSERT INTO `t_api_inter_route` VALUES ('18', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540455826', '1540455826', '1');
INSERT INTO `t_api_inter_route` VALUES ('19', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540455831', '1540455831', '1');
INSERT INTO `t_api_inter_route` VALUES ('20', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540456131', '1540456131', '1');
INSERT INTO `t_api_inter_route` VALUES ('21', '4', 'login.login', '用户登录', 'POST', '的说法是当官的个人合同符合', '复购VR让他发货人挺好用', '1540456188', '1540456188', '1');
INSERT INTO `t_api_inter_route` VALUES ('22', '4', '接口测试', 'test.login', 'POST', 'rfgrd', 'rgfetg', '1540457047', '1540457047', '1');
INSERT INTO `t_api_inter_route` VALUES ('23', '4', '接口测试', 'test.login', 'POST', 'rfgrd', 'rgfetg', '1540457103', '1540457103', '1');
INSERT INTO `t_api_inter_route` VALUES ('24', '4', 'sdf', 'fcsdfc', 'GET', 'fdgvdfgbfh跟他返回法国', '是的规范化', '1540458096', '1540458096', '1');
